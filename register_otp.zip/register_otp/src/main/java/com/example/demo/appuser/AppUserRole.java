package com.example.demo.appuser;

public enum AppUserRole {
    USER,
    ADMIN
}
